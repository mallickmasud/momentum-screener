# Smart Momentum Screener App
This is a Streamlit web app that helps screen momentum stocks based on RSI and SMA indicators using NSE/BSE data via Yahoo Finance.